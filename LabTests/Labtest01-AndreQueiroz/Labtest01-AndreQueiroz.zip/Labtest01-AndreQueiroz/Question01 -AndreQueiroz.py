# -*- coding: utf-8 -*-
"""
Created on Mon Oct 16 09:28:22 2017

@author: andre
"""
#0e 1r 2Pyt 5e 6r 7ho 9z 10n 11i, 14s 16gr 18hj 20ea 22b 23tm
a = "erPyterhozn i,s grhjeabtm"
print(a[2:5]+a[7:9]+a[10]+a[11]+a[12]+a[14]+a[15]+a[16:18]+a[20:22]+a[23])