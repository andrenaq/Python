dict = {'empName': 'Simon', 'title': 'Director', 'yOfEmp': 8, 'title': 'Teacher' }
print (dict['title']) 
print ('The job title of{}is{}'. format(dict ['empName'],dict ['title']))
print ('The job title of', dict['empName'],'is',dict['title'])