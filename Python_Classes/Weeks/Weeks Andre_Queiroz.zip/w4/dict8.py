dict = {'k0':'3', 'k1':'89', 'z4':'5', 'd3':'0'};
sortedDict = sorted(dict.items())
for k,v in sortedDict:
	print (k, v)

	