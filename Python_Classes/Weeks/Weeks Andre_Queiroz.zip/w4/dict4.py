myDict = {'empName': 'Simon', 'title': 'Director', 'yOfEmp': 8}
print (myDict)
del myDict ['empName'] # remove entry with key 'Name'
print (myDict)
myDict.clear()     # remove all entries in dict
print (myDict)
del (myDict)
#print (myDict)
#print (str(myDict))
#myDict ['empName']= 'Simon'
#print (myDict)
