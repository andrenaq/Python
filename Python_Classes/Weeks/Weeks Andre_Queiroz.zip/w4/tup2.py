mytuple1=(11, 13,44)
mytuple2=(66, 77,8)
#mytuple1[0]= 55
print(mytuple1+mytuple2)

list1= ['maths', 'che', 'phy', 'bio']
print(list1)
tuple1=tuple(list1)
print ("tuple elements : ", tuple1)