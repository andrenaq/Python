#adding items to a dictionary
dict ={}
dict['key1']='val1'
dict[44.09]='temp'
dict['key3']=('1','2')
dict ['key4']= ['x','y','z']
print(dict)