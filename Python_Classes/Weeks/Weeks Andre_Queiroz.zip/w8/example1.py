# -*- coding: utf-8 -*-
"""
Created on Mon Nov 13 08:05:39 2017

@author: andre
"""

def print_this( myStr ):
 #"This prints a passed string into this function"
    print(myStr)
    return
print_this ('Functions are modular programs')