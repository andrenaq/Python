# -*- coding: utf-8 -*-
"""
Created on Mon Nov 13 09:32:52 2017

@author: andre
"""

def print_keyword( myVal12,myVal1, myStr): 
    #"This prints a passed string into this function" 
    print (myVal1, myStr) 
    return 
# Now you can call print-keyword function 
myStr ='Jan Donald' 
myVal= 12209 
val=44 
print_keyword(val,myStr=myStr, myVal1=8) 
print_keyword(val,myVal1=8, myStr='Tim')
