# -*- coding: utf-8 -*-
"""
Created on Mon Oct 30 09:34:57 2017

@author: andre
"""

dig =10
while dig>0:
    print('The current value is:', dig)
    dig -=1
    if dig ==5:break
else: print('Thanks')
#print('Thanks')