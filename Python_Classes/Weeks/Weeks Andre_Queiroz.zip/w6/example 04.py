# -*- coding: utf-8 -*-
"""
Created on Mon Oct 30 09:34:57 2017

@author: andre
"""

dig =15
while dig>0:
    dig -=1
    if dig ==7:continue
    print('The current value is:', dig)
print('Thanks')