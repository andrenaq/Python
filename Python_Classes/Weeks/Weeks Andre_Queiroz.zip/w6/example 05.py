# -*- coding: utf-8 -*-
"""
Created on Mon Oct 30 09:52:01 2017

@author: andre
"""

li = ['r','y','e','r','s','o','n']
for j in li:
    print(j)
for i in range(len(li)):
    print(li[i])