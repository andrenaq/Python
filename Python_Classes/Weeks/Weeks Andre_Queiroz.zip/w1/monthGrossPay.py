# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 10:30:24 2017

@author: andre
"""

hours = int(input('How many hours have you worked this month? '))
pay_rate = 15
gross_pay = hours * pay_rate
print('The gross is:', gross_pay)

#-------------------------
num1 = int(input("Enter a number: ") )
num2 = int(input("Enter a second number: ") )
#print('The sum of ', num1, ' and ', num2, ' is ', num1+num2, '.', sep='')
print('The sum of {0:1d} an {1:1d} is {2:1d}'.format(num1,num2,num1+num2))

#operators
