# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

hour = 40
pay_rate = 15
gross_pay = hour * pay_rate
print('The gross is:', gross_pay)


sales = int(input('Sales?: '))
number_of_days = 30
total_sales = number_of_days*sales
print('Total Sales: ', \
      total_sales)

score_1 = 5
score_2 = 20
sum = score_1 +\
score_2
print('The sum is', sum)
myList = [score_1,score_2,'car']
print(myList)

