myList = [ 'Monday', 19 , 2000, 'is', 'forgotten']
myList2 =['Wednesday', 8]
myList [4]= 'unforgotten'
print (" an updated list", myList)
print ("the length of this list is :",len ([1, 3, 4] + [5 + 6 + 7])," !")
del myList [4]
print ("my lsit after deleting item at index 4", myList)
print (2000 in myList) # prints True
myList3=['a','b','c','5']
print (max (myList3))#error
print (myList + myList2)
print (len (myList + myList2))
#print (myList.extend(myList2))

