list8= ['physics', 'chemistry', 'maths']
list9= ['English', 'French']
list8.append(list9)
print ("the appended list is: ", list8)
#list8.extend(list9)
#print ("the extended list is: ", list8)
print ("the list8 has ", list8.count," items")
