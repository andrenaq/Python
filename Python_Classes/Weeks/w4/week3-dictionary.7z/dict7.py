list9 = {'id':16,'name':'Kenith'},{'id':109, 'name':'Dayana'},{'id':98,'name':'Tom'}
for x in list9:
	print (x['id'],x['name'])